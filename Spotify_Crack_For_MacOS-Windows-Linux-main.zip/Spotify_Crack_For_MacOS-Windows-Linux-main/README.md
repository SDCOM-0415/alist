# Spotify - Assume We Premium

Spotify Ads Skipper. Just like Spotify Crack. + Lyrics back by maalos that i modify to make it work on latest chrome extension standard.

## For Chrome Progressive Web App (PWA)

**Please Note:** This repository is may not work as Spotify has been updated. 

I might fix it as soon as possible because I use this extension too lol.

## What's New:

- Removed all ads
- No need to skip ads
- Removed premium and install buttons
- Adds back lyrics (thanks to [maalos Repository](https://github.com/maalos/spotify-web-ad-blocker))

<img width="1440" alt="Screenshot 2022-01-08 at 9 34 45 AM" src="https://user-images.githubusercontent.com/83419951/148630845-7035d19b-895b-4b5b-aca4-ac5f61432391.png">

## How to install
I tried to make .crx file but it's need me to upload it on chrome web store and I don't want to do that right now. so...

1. Clone or download this repo into a folder and paste it in somewhere you like.
1. Go to chrome://extensions
2. Make sure **Developer mode** (in the upper right corner) is ON.
3. Drag & drop the folder that contains this repo there.
4. Open Spotify Web and open chrome `Options > More Tools > Create Shortcut...`
5. Check `Open as window` & hit Create
6. Open Spotify as App

**Note:** Don't delete folder containing repo else it won't work.

## Credits

- [Original Repository (by GopalSaraf)](https://github.com/GopalSaraf/Spotify_Crack_For_MacOS-Windows-Linux)
- [Lyrics back (by maalos)](https://github.com/maalos/spotify-web-ad-blocker)
- [Spotify](https://spotify.com)
